# Fisch Mobile Macro (Android source project)

An editable Android Studio project targeting Android 8+ and a modern Samsung Galaxy device. It uses Android MediaProjection for screen capture and an AccessibilityService for user-authorized touch gestures.

## Included fishing modules
- Live screen capture and per-frame analysis
- Live dark-track/bar candidate measurement (not derived from rod stats)
- Bright marker candidate tracking and velocity estimate
- Separate cast-button and reel-button coordinates
- Auto Perfect Cast timing module (requires in-game calibration)
- Auto cast/recast toggle
- Auto reel toggle with a conservative deadband
- Experimental Auto Shake toggle placeholder
- Confidence threshold and manual coordinate settings
- Optional rod labels; unknown rods use the same detector
- GitHub Actions workflow to build a debug APK

## Build
Open this folder in Android Studio, allow Gradle sync, then run `:app:assembleDebug`.
The GitHub Actions workflow builds `app/build/outputs/apk/debug/app-debug.apk` and uploads it as an artifact.

## Required Android setup
1. Install the APK.
2. Open Accessibility Settings and enable **Fisch Mobile Macro** so Android can perform user-authorized gestures.
3. Start screen capture and approve Android's MediaProjection prompt.
4. Calibrate cast and reel button coordinates for your screen layout.

## Important status / limitations
This is an editable engineering build, **not a verified finished macro**. The detector currently uses conservative image heuristics to find a long dark track and bright marker candidates. Fisch UI elements, animation effects, screen scaling, and game updates can cause false detections. The cast-indicator detector is generic and the perfect-cast target must be calibrated against the actual cast meter. Auto Shake is only a settings placeholder in this version. The auto-reel controller is a first-pass directional controller, not yet validated for Fisch's exact hold/release behavior.

No rod stat or rod name is used to infer the live bar width. The current frame is the source of measurement. When detection confidence is low, the controller does not steer.

## Safety and privacy
Screen capture is performed through Android's visible permission prompt. Captured frames are processed locally and are not uploaded. Touch gestures require the user to enable the Android accessibility service. Stop capture from the app to end the session.
