package com.kaiser.fischmacro;

import android.app.Activity;
import android.content.*;
import android.media.projection.MediaProjectionManager;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.*;
import android.widget.*;

public class MainActivity extends Activity {
    private static final int REQUEST_CAPTURE=41;
    private LinearLayout root;
    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(24,24,24,24); root.setBackgroundColor(0xfff5f7fb);
        ScrollView scroll=new ScrollView(this); scroll.addView(root); setContentView(scroll);
        TextView title=new TextView(this); title.setText("Fisch Mobile Macro"); title.setTextSize(26); title.setTextColor(0xff172033); root.addView(title);
        TextView sub=new TextView(this); sub.setText("Live screen tracking • rod-independent measurements"); sub.setTextSize(14); root.addView(sub);
        addSpace();
        addText("1. Enable Android gesture service");
        Button access=button("Open Accessibility Settings"); access.setOnClickListener(v->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))); root.addView(access);
        addText("2. Enable screen capture");
        Button capture=button("Start Live Screen Capture"); capture.setOnClickListener(v->{
            MediaProjectionManager m=(MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
            startActivityForResult(m.createScreenCaptureIntent(),REQUEST_CAPTURE);
        }); root.addView(capture);
        addText("Fishing modules");
        addToggle("Auto Perfect Cast","perfect_cast",true);
        addToggle("Auto Cast / Recast","auto_cast",true);
        addToggle("Auto Reel","auto_reel",true);
        addToggle("Auto Shake (experimental)","auto_shake",false);
        addText("Live detection settings");
        addNumber("Minimum detection confidence (0.50–0.95)","confidence",0.72f);
        addNumber("Perfect-cast target position (0.05–0.95)","perfect_target",0.50f);
        addNumber("Tap duration in milliseconds","tap_ms",65);
        addText("Mobile button calibration (screen pixels)");
        addNumber("Cast button X","cast_x",0);
        addNumber("Cast button Y","cast_y",0);
        addNumber("Reel button X","reel_x",0);
        addNumber("Reel button Y","reel_y",0);
        addText("Rod profiles are optional labels only. Bar width is always measured from the live screen.");
        Spinner rods=new Spinner(this);
        String[] names={"Auto-detect / unknown rod","Black Fairy Rod","Noiseform","Olympian Godbreaker","Plaguereaver","Custom rod"};
        rods.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,names)); root.addView(rods);
        Button stop=button("Stop capture service"); stop.setOnClickListener(v->stopService(new Intent(this,CaptureService.class))); root.addView(stop);
        TextView note=new TextView(this);
        note.setText("\nImportant: live detector and touch timing require testing against the current Fisch interface. Auto Shake and perfect-cast target need calibration; do not assume a successful catch until verified in-game.");
        note.setTextSize(12); note.setTextColor(0xff596579); root.addView(note);
    }
    private void addText(String s){TextView t=new TextView(this);t.setText(s);t.setTextSize(16);t.setTextColor(0xff172033);t.setPadding(0,18,0,6);root.addView(t);}
    private void addSpace(){View v=new View(this);v.setMinimumHeight(14);root.addView(v);}
    private Button button(String s){Button b=new Button(this);b.setText(s);return b;}
    private void addToggle(String label,String key,boolean def){
        Switch sw=new Switch(this);sw.setText(label);sw.setTextSize(15);sw.setChecked(Prefs.get(this,key,def));
        sw.setOnCheckedChangeListener((v,on)->Prefs.put(this,key,on));root.addView(sw);
    }
    private void addNumber(String label,String key,float def){
        addText(label);
        EditText e=new EditText(this);e.setSingleLine(true);e.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);
        float val=Prefs.getFloat(this,key,def); if(key.equals("cast_x")||key.equals("cast_y")||key.equals("reel_x")||key.equals("reel_y")||key.equals("tap_ms")) val=Prefs.getInt(this,key,(int)def);
        e.setText(String.valueOf(val));root.addView(e);
        e.setOnFocusChangeListener((v,has)->{if(!has)saveNumber(key,e.getText().toString());});
    }
    private void saveNumber(String k,String s){try{
        float f=Float.parseFloat(s);
        if(k.equals("confidence"))f=Math.max(.5f,Math.min(.95f,f));
        if(k.equals("perfect_target"))f=Math.max(.05f,Math.min(.95f,f));
        if(k.equals("cast_x")||k.equals("cast_y")||k.equals("reel_x")||k.equals("reel_y")||k.equals("tap_ms"))Prefs.put(this,k,(int)f);
        else Prefs.put(this,k,f);
    }catch(Exception ignored){}}
    @Override protected void onActivityResult(int req,int res,Intent data){
        super.onActivityResult(req,res,data);
        if(req==REQUEST_CAPTURE && res==RESULT_OK && data!=null){
            Intent s=new Intent(this,CaptureService.class);
            s.putExtra(CaptureService.EXTRA_RESULT,res);s.putExtra(CaptureService.EXTRA_DATA,data);
            if(android.os.Build.VERSION.SDK_INT>=26)startForegroundService(s);else startService(s);
        }
    }
}
