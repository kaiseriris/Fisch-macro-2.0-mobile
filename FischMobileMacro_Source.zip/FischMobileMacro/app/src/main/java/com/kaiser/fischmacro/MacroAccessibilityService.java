package com.kaiser.fischmacro;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.os.Build;
import android.view.accessibility.AccessibilityEvent;

public class MacroAccessibilityService extends AccessibilityService {
    private static volatile MacroAccessibilityService instance;
    @Override public void onServiceConnected(){ super.onServiceConnected(); instance=this; }
    @Override public void onAccessibilityEvent(AccessibilityEvent event) {}
    @Override public void onInterrupt() {}
    @Override public void onDestroy(){ if(instance==this) instance=null; super.onDestroy(); }
    public static boolean isReady(){ return instance!=null; }

    public static void tap(float x,float y,long durationMs){
        MacroAccessibilityService s=instance;
        if(s==null) return;
        Path p=new Path(); p.moveTo(x,y);
        GestureDescription.StrokeDescription stroke =
            new GestureDescription.StrokeDescription(p,0,Math.max(35,durationMs));
        GestureDescription.Builder b=new GestureDescription.Builder().addStroke(stroke);
        s.dispatchGesture(b.build(),null,null);
    }
    public static void hold(float x,float y,long durationMs){
        tap(x,y,Math.max(80,durationMs));
    }
}
