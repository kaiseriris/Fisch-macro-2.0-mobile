package com.kaiser.fischmacro;

public class DetectionResult {
    public final boolean barFound, markerFound, castIndicatorFound;
    public final int barLeft, barRight, barTop, barBottom, markerX, markerY, castX;
    public final float confidence;
    public DetectionResult(boolean bf, boolean mf, boolean cf, int l, int r, int t, int b,
                           int mx, int my, int cx, float conf) {
        barFound=bf; markerFound=mf; castIndicatorFound=cf;
        barLeft=l; barRight=r; barTop=t; barBottom=b; markerX=mx; markerY=my; castX=cx; confidence=conf;
    }
    public static DetectionResult none() { return new DetectionResult(false,false,false,0,0,0,0,0,0,0,0); }
}
