package com.kaiser.fischmacro;

import android.graphics.Bitmap;
import android.graphics.Color;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Screen-only detector. It deliberately measures the live track every frame;
 * rod names/stats are never used to infer control-bar width.
 *
 * Heuristics are intentionally conservative and expose confidence. Fisch UI
 * revisions, themes, effects and scaling can require calibration/tuning.
 */
public final class FishDetector {
    private int lastMarkerX = -1;
    private long lastTime;
    private float markerVelocity;
    private int lastBarLeft=-1, lastBarRight=-1;

    public synchronized DetectionResult analyze(Bitmap src, long nowMs) {
        if (src == null || src.isRecycled()) return DetectionResult.none();
        int w=src.getWidth(), h=src.getHeight();
        // Search central/lower gameplay area while retaining the upper region
        // where the described curled S symbol may appear.
        int x0=(int)(w*0.08), x1=(int)(w*0.94);
        int y0=(int)(h*0.28), y1=(int)(h*0.91);
        int step=Math.max(1, Math.min(w,h)/360);

        // Locate a long, mostly horizontal dark track by row density and run length.
        int bestY=-1, bestRun=0, bestL=0, bestR=0;
        for (int y=y0; y<y1; y+=step) {
            int run=0, runL=0;
            for (int x=x0; x<x1; x+=step) {
                int c=src.getPixel(x,y);
                boolean dark=Color.red(c)<62 && Color.green(c)<62 && Color.blue(c)<68 && Color.alpha(c)>160;
                if (dark) { if(run==0) runL=x; run++; }
                else {
                    int len=run*step;
                    if(len>bestRun){bestRun=len;bestY=y;bestL=runL;bestR=x-step;}
                    run=0;
                }
            }
            int len=run*step;
            if(len>bestRun){bestRun=len;bestY=y;bestL=runL;bestR=x1;}
        }
        boolean barFound=bestRun > w*0.18;
        int barL=bestL, barR=bestR, barY=bestY;
        if (barFound) {
            // Expand vertically around the candidate row to estimate track bounds.
            int top=Math.max(y0,barY-h/35), bottom=Math.min(y1,barY+h/35);
            lastBarLeft=barL; lastBarRight=barR;
            // Bright marker candidates: connected-ish horizontal clusters near track.
            int markerX=-1, markerY=-1, markerScore=0;
            for(int y=top;y<=bottom;y+=step){
                int brightRun=0, start=0;
                for(int x=barL;x<=barR;x+=step){
                    int c=src.getPixel(x,y);
                    boolean bright=Color.red(c)>165 && Color.green(c)>165 && Color.blue(c)>165;
                    if(bright){ if(brightRun==0) start=x; brightRun++; }
                    else {
                        int score=brightRun*step;
                        if(score>markerScore && score<barR-barL){
                            markerScore=score; markerX=(start+x-step)/2; markerY=y;
                        }
                        brightRun=0;
                    }
                }
            }
            if(markerX>=0){
                if(lastMarkerX>=0 && nowMs>lastTime){
                    float dt=(nowMs-lastTime)/1000f;
                    if(dt>0 && dt<1.0f) markerVelocity=(markerX-lastMarkerX)/dt;
                }
                lastMarkerX=markerX; lastTime=nowMs;
            }
            float conf=Math.min(0.95f, 0.35f + bestRun/(float)w);
            boolean markerFound=markerX>=0 && markerScore>=step*2;
            // Cast indicator is separately estimated by scanning for a bright moving
            // component in the upper-middle screen. It is not conflated with the fish marker.
            int castX=findBrightIndicator(src,w,h,step);
            boolean castFound=castX>=0;
            return new DetectionResult(true,markerFound,castFound,barL,barR,top,bottom,
                    markerX,markerY,castX, markerFound?Math.min(0.96f,conf+0.08f):conf*0.72f);
        }
        return DetectionResult.none();
    }

    private int findBrightIndicator(Bitmap b,int w,int h,int step){
        int y0=(int)(h*0.38), y1=(int)(h*0.78), x0=(int)(w*0.15), x1=(int)(w*0.88);
        int bestX=-1,bestScore=0;
        for(int x=x0;x<x1;x+=step*2){
            int score=0;
            for(int y=y0;y<y1;y+=step*2){
                int c=b.getPixel(x,y);
                if(Color.red(c)>205 && Color.green(c)>205 && Color.blue(c)>205) score++;
            }
            if(score>bestScore){bestScore=score;bestX=x;}
        }
        return bestScore>=4?bestX:-1;
    }
    public synchronized float getMarkerVelocity(){ return markerVelocity; }
    public synchronized void reset(){lastMarkerX=-1;lastTime=0;markerVelocity=0;lastBarLeft=-1;lastBarRight=-1;}
}
