package com.kaiser.fischmacro;

import android.content.Context;
import android.content.SharedPreferences;

public final class Prefs {
    private static final String FILE = "macro_settings";
    private static SharedPreferences p(Context c) { return c.getSharedPreferences(FILE, Context.MODE_PRIVATE); }
    public static boolean get(Context c, String k, boolean d) { return p(c).getBoolean(k, d); }
    public static int getInt(Context c, String k, int d) { return p(c).getInt(k, d); }
    public static float getFloat(Context c, String k, float d) { return p(c).getFloat(k, d); }
    public static void put(Context c, String k, boolean v) { p(c).edit().putBoolean(k, v).apply(); }
    public static void put(Context c, String k, int v) { p(c).edit().putInt(k, v).apply(); }
    public static void put(Context c, String k, float v) { p(c).edit().putFloat(k, v).apply(); }
}
