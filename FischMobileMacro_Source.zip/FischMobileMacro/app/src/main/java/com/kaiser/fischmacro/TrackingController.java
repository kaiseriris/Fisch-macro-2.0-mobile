package com.kaiser.fischmacro;

import android.content.Context;
import android.os.SystemClock;

/** State machine separating cast tap, perfect-cast timing, shake, and reel tracking. */
public final class TrackingController {
    private final Context context;
    private long lastAction;
    private int lostFrames;
    private int lastMarkerX=-1;
    private boolean enabled=true;
    public TrackingController(Context c){context=c.getApplicationContext();}

    public void onFrame(DetectionResult d, int screenW, int screenH, FishDetector detector){
        if(!enabled) return;
        long now=SystemClock.elapsedRealtime();
        boolean autoCast=Prefs.get(context,"auto_cast",true);
        boolean perfect=Prefs.get(context,"perfect_cast",true);
        boolean autoReel=Prefs.get(context,"auto_reel",true);
        float threshold=Prefs.getFloat(context,"confidence",0.72f);

        // Do not issue steering actions from low-confidence or missing detections.
        if(!d.barFound || d.confidence<threshold){
            lostFrames++;
            if(lostFrames>8) lastMarkerX=-1;
            return;
        }
        lostFrames=0;

        // Perfect-cast: tap only when a moving indicator is actually observed.
        // This initial heuristic uses the measured indicator's approach to a
        // configurable target; target calibration is stored as screen fraction.
        if(autoCast && perfect && d.castIndicatorFound && now-lastAction>500){
            float target=Prefs.getFloat(context,"perfect_target",0.50f);
            int targetX=(int)(screenW*target);
            float vx=detector.getMarkerVelocity();
            int castX=d.castX;
            if(Math.abs(castX-targetX)<Math.max(8,screenW*0.012f)){
                int buttonX=Prefs.getInt(context,"cast_x",screenW*85/100);
                int buttonY=Prefs.getInt(context,"cast_y",screenH*85/100);
                MacroAccessibilityService.tap(buttonX,buttonY,Prefs.getInt(context,"tap_ms",65));
                lastAction=now;
            }
        }

        if(autoReel && d.markerFound && now-lastAction>90){
            int center=(d.barLeft+d.barRight)/2;
            int marker=d.markerX;
            int x=Prefs.getInt(context,"reel_x",screenW*85/100);
            int y=Prefs.getInt(context,"reel_y",screenH*85/100);
            // Small deadband; direction follows the measured marker/bar offset.
            int error=marker-center;
            if(Math.abs(error)>Math.max(5,(d.barRight-d.barLeft)/18)){
                long duration=Math.min(180,Math.max(45,Math.abs(error)/3));
                if(error>0) MacroAccessibilityService.hold(x,y,duration);
                else MacroAccessibilityService.tap(x,y,55);
                lastAction=now;
            }
            lastMarkerX=marker;
        }
    }
    public void setEnabled(boolean v){enabled=v;}
}
