package com.kaiser.fischmacro;

import android.app.*;
import android.content.*;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.*;
import java.nio.ByteBuffer;

public class CaptureService extends Service {
    public static final String EXTRA_RESULT="resultCode", EXTRA_DATA="data";
    private MediaProjection projection;
    private VirtualDisplay display;
    private ImageReader reader;
    private HandlerThread thread;
    private FishDetector detector;
    private TrackingController controller;
    private int width,height,density;
    private volatile boolean running;

    @Override public void onCreate(){
        super.onCreate();
        detector=new FishDetector();
        controller=new TrackingController(this);
        thread=new HandlerThread("screen-analysis"); thread.start();
    }
    @Override public int onStartCommand(Intent i,int flags,int id){
        createNotification();
        if(i!=null && i.hasExtra(EXTRA_DATA) && projection==null){
            int code=i.getIntExtra(EXTRA_RESULT,Activity.RESULT_CANCELED);
            Intent data=i.getParcelableExtra(EXTRA_DATA);
            MediaProjectionManager m=(MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
            projection=m.getMediaProjection(code,data);
            startCapture();
        }
        return START_STICKY;
    }
    private void createNotification(){
        String channel="fisch_macro_capture";
        if(Build.VERSION.SDK_INT>=26){
            NotificationChannel c=new NotificationChannel(channel,"Screen tracking",NotificationManager.IMPORTANCE_LOW);
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);
        }
        Notification n=new Notification.Builder(this,channel).setContentTitle("Fisch Mobile Macro")
            .setContentText("Live screen tracking is active").setSmallIcon(android.R.drawable.ic_media_play).build();
        startForeground(7,n);
    }
    private void startCapture(){
        android.util.DisplayMetrics dm=getResources().getDisplayMetrics();
        width=dm.widthPixels; height=dm.heightPixels; density=dm.densityDpi;
        reader=ImageReader.newInstance(width,height, PixelFormat.RGBA_8888,2);
        reader.setOnImageAvailableListener(r->{
            Image image=null;
            try{
                image=r.acquireLatestImage();
                if(image==null)return;
                Image.Plane plane=image.getPlanes()[0];
                ByteBuffer buffer=plane.getBuffer();
                int pixelStride=plane.getPixelStride(), rowStride=plane.getRowStride();
                int rowPadding=rowStride-pixelStride*width;
                Bitmap padded=Bitmap.createBitmap(width+rowPadding/pixelStride,height,Bitmap.Config.ARGB_8888);
                padded.copyPixelsFromBuffer(buffer);
                Bitmap frame=Bitmap.createBitmap(padded,0,0,width,height);
                padded.recycle();
                DetectionResult result=detector.analyze(frame,SystemClock.elapsedRealtime());
                controller.onFrame(result,width,height,detector);
                frame.recycle();
            }catch(Throwable ignored){} finally {if(image!=null)image.close();}
        },new Handler(thread.getLooper()));
        display=projection.createVirtualDisplay("FischMacroScreen",width,height,density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,reader.getSurface(),null,new Handler(thread.getLooper()));
        running=true;
    }
    @Override public void onDestroy(){
        running=false;
        if(display!=null)display.release();
        if(reader!=null)reader.close();
        if(projection!=null)projection.stop();
        if(thread!=null)thread.quitSafely();
        super.onDestroy();
    }
    @Override public android.os.IBinder onBind(Intent intent){return null;}
}
